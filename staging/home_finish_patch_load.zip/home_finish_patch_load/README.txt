Carga Home Finish corrigida

Arquivos incluídos:
- MI201020
- MI201021
- BH101037
- BH101031
- BH101015
- BH101013
- BH101012

Observação: as duas imagens MI201020 e MI201021 já foram salvas na orientação correta (upright), prontas para substituição.
